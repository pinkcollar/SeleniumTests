public enum DriverType {
    CHROME, FIREFOX, IE;
}

