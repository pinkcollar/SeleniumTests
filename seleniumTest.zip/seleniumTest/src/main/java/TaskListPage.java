import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
public class TaskListPage {
    WebDriver driver;
    public TaskListPage(WebDriver driver){
        this.driver = driver;
    }

    private By fortinetLink = By.linkText("Fortinet");

    private By taskNameTextField = By.cssSelector(".item-add-field:nth-child(1) > label");
    private By deadlineSelectionField = By.cssSelector(".item-add-field:nth-child(2) > label");
    private By completeCheckbox = By.cssSelector(".item-add-field:nth-child(3) > label");
    private By addItemButton = By.id("add-item");

    public String getTitle(){
        return driver.getTitle();
    }


    public WebElement getWebElement(By locator) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            return driver.findElement(locator);
        } catch (NoSuchElementException e) {
            throw new RuntimeException(locator + " element was not found", e);
        }
    }

    public WebElement getFortinetLink() {
        return getWebElement(fortinetLink);
    }

    public WebElement getTaskNameTextField() {
        return getWebElement(taskNameTextField);
    }

    public WebElement getDeadlineSelectionField(){
        return getWebElement(deadlineSelectionField);
    }

    public WebElement getCompleteCheckbox(){
        return getWebElement(completeCheckbox);
    }

    public WebElement getAddItemButton(){
        return getWebElement(addItemButton);
    }


}
