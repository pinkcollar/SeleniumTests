import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;
public class SeleniumListLoadTest {
    DriverManager driverManager;
    WebDriver driver;
    TaskListPage taskListPage;

    @BeforeClass
    public  void setupClass() {
        driver = null;
        driverManager = DriverManagerFactory.getDriverManager(DriverType.CHROME);
        driver = driverManager.getWebDriver();
        String URL = "http://s3.amazonaws.com/istreet-assets/bHFRMn4JHQnwP7QcqCer7w/fortinet-qa-testsite.html";
        driver.get(URL);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        taskListPage = new TaskListPage(driver);
    }


    @Test
    public void ListLoadTest(){
        taskListPage.getFortinetLink();
        taskListPage.getTitle();
        taskListPage.getTaskNameTextField();
        taskListPage.getCompleteCheckbox();
        taskListPage.getDeadlineSelectionField();
        taskListPage.getAddItemButton();
    }


    @AfterClass
    public void tearDown() {
        if (driver != null)
            driver.quit();
    }
}
